API_ID = 123456  # api id
API_HASH = "ABC-DEF1234ghIkl-zyx57W2v1u123ew11"  # api hash

BOT_TOKEN = "123456:ABC-DEF1234ghIkl-zyx57W2v1u123ew11"  # bot token


# REDIS
HOST = "localhost"  # redis host uri
PORT = 6379  # redis port
PASSWORD = ""  # redis password

PRIVATE_CHAT_ID = -1001234567890  # CHAT WHERE YOU WANT TO STORE VIDEOS
# COOKIE FOR AUTHENTICATION (get from chrome dev tools) ex: "PANWEB=1; csrfToken=;
COOKIE = ""
ADMINS = [1317173146]


BOT_USERNAME = "teraboxdown_bot"

# Force user to join this channel. (make sure you have promoted the bot on this chat.)
FORCE_LINK = "@RoldexVerse"

PUBLIC_EARN_API = ""  # https://publicearn.com/api
